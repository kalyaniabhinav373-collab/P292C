# ProtoLab Studio X — Physics Edition

A self-contained browser electronics simulator prototype.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `ProtoLab-Studio-X`).
2. Upload `index.html` to the repository root and commit it.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. After GitHub Pages finishes deploying, your site URL will be `https://YOUR-USERNAME.github.io/ProtoLab-Studio-X/`.

This is a client-side HTML app. No backend server is included. Browser behavior and the accuracy of each component model depend on the simulator implementation.
